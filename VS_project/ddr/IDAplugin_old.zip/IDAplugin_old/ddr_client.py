# Dependancies:
#	pip install -U requests

import requests
import sys
from pprint import pprint

def call_api(cmd_id=0, dynrio_sample=None, start_addr=None, end_addr=None, instr_count=None, arch_bits=None ):

	WEBSERVER          = "127.0.0.1"
	WEBSERVER_PORT     = "5000"
	MAX_API_TIMEOUT    = 600.0			# in seconds
	DDR_WEBAPI_KEY     = "KT5LUFCHHSO12986OPZTWEFS"

	try:
		url = "https://" + WEBSERVER + ":" + WEBSERVER_PORT + "/api/v1/cmd" 

		# Run sample file 
		if cmd_id == 1:

			postpara = { 'id'            : cmd_id , 
			             'apikey'        : DDR_WEBAPI_KEY, 
			             'end_addr'      : end_addr, 
			             'start_addr'    : start_addr, 
			             'dynrio_sample' : dynrio_sample, 
			             'instr_count'   : instr_count,
			             'arch_bits'     : arch_bits }

			res = requests.post(url, verify="ddr_server.crt", data = postpara, timeout=MAX_API_TIMEOUT)
			if res.status_code == 200:
				print("return status: %s" % res.json()['return_status'])
				if res.json()['return_status'] == "success":
					print("stdout from cmd:")
					print("--------------------------------------------------")
					print("stdout: %s" % res.json()['stdout'])
					print("--------------------------------------------------")
			else:
				res.raise_for_status()

	 	# download samplefile
		if cmd_id == 2:
			postpara = { 'id'            : cmd_id , 
			             'apikey'        : DDR_WEBAPI_KEY, 
			             'end_addr'      : end_addr, 
			             'start_addr'    : start_addr, 
			             'dynrio_sample' : dynrio_sample, 
			             'instr_count'   : instr_count,
			             'arch_bits'     : arch_bits }
			
			localfile = "c:\\users\\dexdex~1\\appdata\\local\\temp\\testfile.txt"
			res = requests.post(url, verify="ddr_server.crt", data = postpara, timeout=MAX_API_TIMEOUT, stream=True)
			if res.status_code == 200:
				with open(localfile, 'wb') as f:
					for chunk in res.iter_content():
						f.write(chunk)
				print("Downloaded file: %s" % localfile)
			else:
				res.raise_for_status()

	except requests.exceptions.SSLError as e:
		print("[SSL ERROR]: %s" % e)

	except requests.exceptions.ConnectionError as e:
		print("[CONNECTION ERROR]: %s" % e)
		print("\nDid you start and configure the DDR server script or is there any firewall inbetween ?")

	except requests.exceptions.HTTPError as e:
		print("[HTTP ERROR]: %s" % e)
		print("\nCMD execution failed. Check server side for details")

	except requests.exceptions.ReadTimeout as e:
		print("[TIMEOUT ERROR]: %s" % e)

	except ValueError as e:
		print("JSON ERROR: Failed to decode the returned data: %s\n" % e)

	except:
		print("[ERROR] Unkown error happend. REST API request failed.")
		raise

if __name__ == "__main__":

	cmd_id = int(sys.argv[1])
	dynrio_sample = "C:\\Users\\Dex Dexter\\Documents\\Visual Studio 2017\\Projects\\hello_world\\Release\\hello_world.exe"
	start_addr=0x401160
	end_addr=0x4011ab
	instr_count = 10000
	arch_bits = 32

	call_api(cmd_id=cmd_id, dynrio_sample=dynrio_sample, start_addr=start_addr, end_addr=end_addr, instr_count=instr_count, arch_bits=arch_bits )

