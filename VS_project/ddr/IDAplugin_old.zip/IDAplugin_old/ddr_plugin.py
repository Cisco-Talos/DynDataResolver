
import idaapi
import idautils
import idc
import logging
import tempfile
import os
import errno
import json
from datetime import datetime
#import PyQt5.QtWidgets as QtWidgets
import inspect

from pprint import pprint

from idaapi import PluginForm, Choose2
from PyQt5 import QtCore, QtGui, QtWidgets

# Setup Logging to file in %TEMP%
tmpdir = tempfile.gettempdir()
ddr_logdir = tmpdir + '\DDR'

try:
    os.makedirs(ddr_logdir, exist_ok=True)    # Python >3.2
except TypeError:
    try:
        os.makedirs(ddr_logdir)               # Python >2.5
    except OSError as e:
        if e.errno == errno.EEXIST and os.path.isdir(ddr_logdir):
            pass
        else:
            idaapi.warning("[DDR] Failed to make logging directory")

ddr_logfilename = ddr_logdir + '\DDR-{:%Y-%m-%d-%H-%M-%S}.log'.format(datetime.now())
logger = logging.getLogger("DDR")
logger.setLevel(logging.DEBUG)
fh = logging.FileHandler(ddr_logfilename)
fh.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
logger.addHandler(fh)

# Globals
act_name_load_file             = "DDR_Action_Load_file"
act_name_Get_Values_OP0        = "DDR_Action_Find_Values_OP0"
act_name_Get_Values_OP1        = "DDR_Action_Find_Values_OP1"
act_name_Get_Mem_Ptr_OP0       = "DDR_Action_Get_Mem_Ptr_OP0"
act_name_Get_Mem_Ptr_OP1       = "DDR_Action_Get_Mem_Ptr_OP1"
act_name_Get_Mem_Ptr_Ptr_OP0   = "DDR_Action_Get_Mem_Ptr_Ptr_OP0"
act_name_Get_Mem_Ptr_Ptr_OP1   = "DDR_Action_Get_Mem_Ptr_Ptr_OP1"
act_name_Get_Mem_Ptr_xax       = "DDR_Action_Get_Mem_Ptr_xax"
act_name_Get_Mem_Ptr_xbx       = "DDR_Action_Get_Mem_Ptr_xbx"
act_name_Get_Mem_Ptr_xcx       = "DDR_Action_Get_Mem_Ptr_xcx"
act_name_Get_Mem_Ptr_xdx       = "DDR_Action_Get_Mem_Ptr_xdx"
act_name_Get_Mem_Ptr_xsp       = "DDR_Action_Get_Mem_Ptr_xsp"
act_name_Get_Mem_Ptr_xbp       = "DDR_Action_Get_Mem_Ptr_xbp"
act_name_Get_Mem_Ptr_xsi       = "DDR_Action_Get_Mem_Ptr_xsi"
act_name_Get_Mem_Ptr_xdi       = "DDR_Action_Get_Mem_Ptr_xdi"
act_name_Get_Mem_Ptr_r8        = "DDR_Action_Get_Mem_Ptr_r8"
act_name_Get_Mem_Ptr_r9        = "DDR_Action_Get_Mem_Ptr_r9"
act_name_Get_Mem_Ptr_r10       = "DDR_Action_Get_Mem_Ptr_r10"
act_name_Get_Mem_Ptr_r11       = "DDR_Action_Get_Mem_Ptr_r11"
act_name_Get_Mem_Ptr_r12       = "DDR_Action_Get_Mem_Ptr_r12"
act_name_Get_Mem_Ptr_r13       = "DDR_Action_Get_Mem_Ptr_r13"
act_name_Get_Mem_Ptr_r14       = "DDR_Action_Get_Mem_Ptr_r14"
act_name_Get_Mem_Ptr_r15       = "DDR_Action_Get_Mem_Ptr_r15"
act_name_Set_Num_Hits_Cmt      = "DDR_Action_Set_Num_Hits_for_Cmt"
act_name_Set_Num_Hits_IdaLog   = "DDR_Action_Set_Num_Hits_for_IdaLog"
act_name_Strings_View          = "DDR_Action_Strings_View"
act_name_DeleteNonRepeatableComments     = "DDR_Action_DeleteNonRepeatableComments"

jsondata = None
jsonfile_loaded = False

MAX_LOG_ROUNDS = 5     # Max. number of found instruction values added to the IDA log window
MAX_CMT_ROUNDS = 3      # Max. number of found instruction values added to the IDA DISASM view as comments
MAX_INSTR_COUNT = 50    # Max. number of instruction addresses wich will be added to the trace_instr_num_list

usr_dbglevel = 7
arch_bits = None

reg_list = []

def PLUGIN_ENTRY():
    return ddrPlugin()

# only works with a sngle thread, use IDA build in fuction for multi threaded stuff
# idaapi.execute_ui_requests(....) check this API details 

# many things are not thread safe
# check out IDAWrapper function (executes things from the main thread... makes it a kind of thread safe)

def print_mesg(msg, debuglevel=0):
    """
    Print msg to output window in IDA
    """
    func = inspect.stack()[1][3] # Get calling function name

    if debuglevel == 0 and usr_dbglevel >= 0:
        print("[DDR] %s" % msg)
    if debuglevel == 1 and usr_dbglevel >= 1:
        print("[DDR] %s" % msg)
    if debuglevel == 2 and usr_dbglevel >= 2:
        print("[DDR] %s" % msg)
    if debuglevel == 3 and usr_dbglevel >= 3:                           
        print("[DDR][DEBUG_3][%s] %s" % (func, msg))
    if debuglevel == 4 and usr_dbglevel >= 4:
        print("[DDR][DEBUG_4][%s] %s" % (func, msg))
    if debuglevel == 5 and usr_dbglevel >= 5:
        print("[DDR][DEBUG_5][%s] %s" % (func, msg))
    if debuglevel == 6 and usr_dbglevel >= 6:
        print("[DDR][DEBUG_6][%s] %s" % (func, msg))  
    if debuglevel == 7 and usr_dbglevel >= 7:
        print("[DDR][DEBUG_7][%s] %s" % (func, msg))

class DDR_ida_action_handler(idaapi.action_handler_t):
    """
    DDR Action handler for all menu entries, gets created when user picks menu 
    """

    def __init__(self, usrcmd):
        idaapi.action_handler_t.__init__(self)
        self.cmd = usrcmd
        print_mesg("cmd = %s" % self.cmd, 7)

    def activate(self, ctx):
        """
        Execute the embedded action_function when this context menu is invoked.
        """
        print_mesg("Command selected by user: [%s]" % self.cmd, 7)
        
        global jsondata
        global jsonfile_loaded
        global MAX_LOG_ROUNDS
        global MAX_CMT_ROUNDS

        ea = idc.ScreenEA()

        if self.cmd == ("Get_Set_Num_Hits_Cmt"):
            cmt_rnds = idc.AskLong(MAX_CMT_ROUNDS, "Please enter number of hits to display in IDA comments:")
            if cmt_rnds != -1:
                MAX_CMT_ROUNDS = cmt_rnds
                print_mesg("[Get_Set_Num_Hits_Cmt] Number of hits for repeatble comments %d" % MAX_CMT_ROUNDS, 7) 
            return 1

        if self.cmd == ("Get_Set_Num_Hits_IdaLog"):
            cmt_rnds = idc.AskLong(MAX_LOG_ROUNDS, "Please enter number of hits to display in IDA comments:")
            if cmt_rnds != -1:
                MAX_LOG_ROUNDS = cmt_rnds
                print_mesg("[Get_Set_Num_Hits_IdaLog] Number of hits for IDA log window %d" % MAX_LOG_ROUNDS, 7) 
            return 1

        if self.cmd == ("Display_Strings_View"):
            if(jsonfile_loaded == False):
                print_mesg("JSON file not loaded. Starting JSON file dialog...")
                print_mesg("Alternativly, you can use 'File/Load File/Load DynRIO file' to load it first.")
                if self._load_JSON_file():
                    self.activate(ctx)
            else:
                items = self.get_chooser_row_list()
                print_mesg("Len items: %d" % len(items),7)
                c = MyChoose2("Trace Strings", items=items, modal=False)
                if not c.show():
                    print_mesg("Failed to start Trace Strings View", 7)
                else:
                    print_mesg("Trace Strings View created", 7)
                return 1 

        # Load DynamoRIO JSON File 
        if self.cmd == "LoadFile" :
            self._load_JSON_file()

        # Resolve dynamic data based on JSON file data
        if(jsonfile_loaded == True):
            try:
                _ , start, end = idaapi.read_selection()
                # User selected multiple lines
                if self._selection_is_valid(start, end, ea):
                    print_mesg("[%s] selected processing range: %x - %x" % (self.cmd, start, end),7)
                    ea=start
                    while(ea <= end):
                        if self.cmd == "DeleteNonRepeatableComments":
                            print_mesg("[Range] Delete non-repeatable comments.... %x" % ea, 7)   
                            idc.MakeComm(ea, "")         
                        else:
                            self._parse_ea(ea)

                        ea = idc.NextHead(ea)
                # User selected single line
                else:
                    print_mesg("[%s] selected address: %x" % (self.cmd, ea),7)
                    if self.cmd == "DeleteNonRepeatableComments":
                        print_mesg("[SingleAddress] Delete non-repeatable comments.... %x" % ea, 7)
                        idc.MakeComm(ea, "")
                    else:
                        self._parse_ea(ea)
            except:
                raise
        else:
            # JSON file not loaded, load it and execute method again
            print_mesg("JSON file not loaded. Starting JSON file dialog...")
            print_mesg("Alternativly, you can use 'File/Load File/Load DynRIO file' to load it first.")
            if self._load_JSON_file():
                self.activate(ctx)
            
        return 1

    def update(self, ctx):
        """
        Ensure the context menu is always available in IDA.
        """
        print_mesg("[%s] updated." % self.cmd, 7)
        return idaapi.AST_ENABLE_ALWAYS

    def _load_JSON_file(self):
        """ Loads DynamoRIO generated JSON file """
        global jsondata
        global jsonfile_loaded

        filename = self._get_JSON_file()

        try:
            with open(filename) as json_file:  
                jsondata = json.load(json_file)
                jsonfile_loaded = True
                print_mesg("JSON file was generated for executable: %s" % (jsondata["samplename"]))
                return True
        except IOError as e:
            print_mesg("Failed to open JSON file. Quitting operation.")
            jsonfile_loaded = False
            return False
        except ValueError as e:
            print_mesg("[ERROR] Failed to parse JSON file: %s. Quitting operation." % filename)
            print_mesg("[ERROR] Please check file format is JSON and try again.")
            e_args = ''.join(map(str,e.args))
            print_mesg("%s" % e_args)
            jsonfile_loaded = False
            idaapi.warning("[DDR] Failed to open JSON file. Check Logging window for details.")
            return False
        else:
            print_mesg("[ERROR] Failed to open JSON file: %s with unknown error. Quitting operation." % filename)
            jsonfile_loaded = False
            idaapi.warning("[DDR] Failed to open JSON file. Check Logging window for details.")
            raise

    def _get_JSON_file(self):
        """
        Prompt a file selection dialog, returning file selections.
        """
        my_dir = "C:\\Users\\Dex Dexter\\Documents\\Visual Studio 2017\\Projects\\dr_hu1\\x64\\Release"

        # create & configure a Qt File Dialog for immediate use
        file_dialog = QtWidgets.QFileDialog(
            None,
            'Open DDR DynamoRIO generated JSON file',
            #idautils.GetIdbDir(),
            my_dir,
            'All Files (*.*)'
        )
        file_dialog.setFileMode(QtWidgets.QFileDialog.ExistingFiles)

        # prompt the user with the file dialog, and await filename(s)
        filename, _ = file_dialog.getOpenFileName()

        # log the selected filenames from the dialog
        print_mesg("DynRIO JSON input file loaded: %s" % filename)

        # return the captured filenames
        return filename

    def _selection_is_valid(self, start, end, ea):
        """If the cursor is not at the beginning or the end of our selection, assume that
        something bad has gone wrong and bail out instead of turning a lot of important
        things into dwords.
        """
        if not (ea == start or ea == end):
            return False
        else:
            return True


    def get_chooser_row_list(self) :
        """ Fill the lines list used for the Trace Window item list"""

        lines = []
        for instr_num, instr in enumerate(jsondata["instruction"]):                               
            for s in [ "inst_mem_addr_src0_data", "inst_mem_addr_src0_data_ptr_data"]:
                try:
                    line  = []
                    line.append("%10d" % instr_num)           # instruction number in trace
                    line.append(str(instr["address"]))    # ea address of instruction
                    line.append(s)                        # JSON field (type) of string
                    mystring = str(instr[s])
                    stringlist = mystring.split("    ")
                    line.append(stringlist[0])            # String in Hex
                    line.append("".join(stringlist[1:]))  # String
                    line.append(str(instr["disasm"]))     # Disasm of instruction
                    lines.append(line)
                except KeyError as e:
                    break

        return lines

    def _parse_ea(self, ea):
        """
        Main parser method for parsng and analysing data at address (ea)
        """
        
        op0 = idc.GetOpnd(ea,0)
        op1 = idc.GetOpnd(ea,1)
        op0_type = idc.GetOpType(ea,0)
        op1_type = idc.GetOpType(ea,1)

        print_mesg("Address: 0x%x:" % ea)
        print_mesg("  DISASM   : %s" % idc.GetDisasm(ea))
        print_mesg("  CMD      : %s" % self.cmd, 7)
        print_mesg("  OP count : %d" % self._op_count(ea),7)
        print_mesg("  OP0      : %s" % op0,7)
        print_mesg("  OP1      : %s" % op1,7)
        print_mesg("  OP0 type : %x" % op0_type,7)
        print_mesg("  OP1 type : %x" % op1_type,7)
        print_mesg("  OP0 value: %x" % idc.GetOperandValue(ea,0),7)
        print_mesg("  OP1 value: %x" % idc.GetOperandValue(ea,1),7)

        # --- FindValue selected ---
        if self.cmd=="FindValueOP0":
            # OP0 is Register
            if op0_type == idaapi.o_reg:
                reg, trace_instr_num_list = self._get_trace_instr_list_for_op_reg(op0, 0, ea)
                self._set_ida_comment_reg(ea, reg, trace_instr_num_list,0)
            # OP0 is memory reference
            elif op0_type != idaapi.o_void: 
                trace_instr_num_list = self._get_trace_instr_list_for_op_mem(ea)
                self._set_ida_comment_mem(ea, trace_instr_num_list) 

        if self.cmd=="FindValueOP1":
            # OP0 is Register
            if op1_type == idaapi.o_reg:
                reg, trace_instr_num_list = self._get_trace_instr_list_for_op_reg(op1, 1, ea)
                self._set_ida_comment_reg(ea, reg, trace_instr_num_list,1)
            # OP0 is memory reference
            elif op1_type != idaapi.o_void: # op1_type in [ idaapi.o_mem, idaapi.o_phrase, idaapi.o_displ ]: TBD, maybe change to a closer check
                trace_instr_num_list = self._get_trace_instr_list_for_op_mem(ea)
                self._set_ida_comment_mem(ea, trace_instr_num_list) 

        # --- Get_Mem_Ptr selected ---
        if self.cmd=="Get_Mem_Ptr_OP0":
            # OP0 is Register
            if op0_type == idaapi.o_reg:
                reg, trace_instr_num_list = self._get_trace_instr_list_for_op_reg(op0, 0, ea)
                self._set_ida_comment_mem_ptr(ea, trace_instr_num_list)
            # OP0 is memory reference
            elif op0_type != idaapi.o_void:
                trace_instr_num_list = self._get_trace_instr_list_for_op_mem(ea)
                self._set_ida_comment_mem_ptr(ea, trace_instr_num_list) 

        if self.cmd=="Get_Mem_Ptr_OP1":
            # OP0 is Register
            if op1_type == idaapi.o_reg:
                reg, trace_instr_num_list = self._get_trace_instr_list_for_op_reg(op1, 1, ea)
                self._set_ida_comment_mem_ptr(ea, trace_instr_num_list)
            # OP0 is memory reference
            elif op1_type != idaapi.o_void:
                trace_instr_num_list = self._get_trace_instr_list_for_op_mem(ea)
                self._set_ida_comment_mem_ptr(ea, trace_instr_num_list) 

        # --- Get_Mem_Ptr_Ptr selected ---
        if self.cmd=="Get_Mem_Ptr_Ptr_OP0":
            # OP0 is Register
            if op0_type == idaapi.o_reg:
                reg, trace_instr_num_list = self._get_trace_instr_list_for_op_reg(op0, 0, ea)
                self._set_ida_comment_mem_ptr_ptr(ea, trace_instr_num_list)
            # OP0 is memory reference
            elif op0_type != idaapi.o_void:
                trace_instr_num_list = self._get_trace_instr_list_for_op_mem(ea)
                self._set_ida_comment_mem_ptr_ptr(ea, trace_instr_num_list) 

        if self.cmd=="Get_Mem_Ptr_Ptr_OP1":
            # OP0 is Register
            if op1_type == idaapi.o_reg:
                reg, trace_instr_num_list = self._get_trace_instr_list_for_op_reg(op1, 1, ea)
                self._set_ida_comment_mem_ptr_ptr(ea, trace_instr_num_list)
            # OP0 is memory reference
            elif op1_type != idaapi.o_void: 
                trace_instr_num_list = self._get_trace_instr_list_for_op_mem(ea)
                self._set_ida_comment_mem_ptr_ptr(ea, trace_instr_num_list) 

        # --- Register Ptr selected ---
        # reg_list64 = ["xax","xbx","xcx","xdx","xsp","xbp","xsi","xdi","r8","r9","r10","r11","r12","r13","r14","r15"]
        # reg_list32 = ["xax","xbx","xcx","xdx","xsp","xbp","xsi","xdi"]
        global reg_list
        for reg in reg_list:
            print_mesg("reg:%s" % reg , 7) 
            if self.cmd=="Get_Mem_Ptr_" + reg:
                trace_instr_num_list = self._get_trace_instr_list_for_op_mem(ea)
                self._set_ida_comment_regmenu_mem_ptr(ea, reg, trace_instr_num_list)

        print("-------------------------------------------------------------------------------")
        return True

    def _set_ida_comment_reg(self, ea, reg, trace_instr_num_list, opnum):
        """ Prints out values if operant is a register and adds a comment to the disasm view"""
        comment = ""

        if not trace_instr_num_list:
            comment = "0x%x not in trace" % ea

        for c,i in enumerate(trace_instr_num_list):
            if c < MAX_LOG_ROUNDS:
                print_mesg("   Val(OP%d[%s])@instr number:%07d = %s" % (opnum,reg, i, jsondata["instruction"][i][reg]))
            if c < MAX_CMT_ROUNDS:
                comment += "Val(OP%d[%s]):0x%x;" % (opnum,reg,int(jsondata["instruction"][i][reg],16)) 

        # Get existing commend and add our dynamic data to it.
        org_cmt = idc.GetCommentEx(ea, False)
        if org_cmt != None:
            new_comment = org_cmt + "\n" + comment
        else:
            new_comment = comment

        idc.MakeComm(ea, new_comment)

    def _set_ida_comment_mem(self, ea, trace_instr_num_list):
        """ Prints out data if operant is a memory address and adds a comment to the disasm view"""

        comment = ""

        if not trace_instr_num_list:
            comment = "0x%x not in trace" % ea

        for c,i in enumerate(trace_instr_num_list):
            if self.cmd == "FindValueOP0":
                try:
                    if c < MAX_LOG_ROUNDS:
                        print_mesg("    Val(OP0)@0x%x@instr number:%07d = 0x%x" % (ea, i, int(jsondata["instruction"][i]["inst_mem_addr_dst0"],16)))
                    if c < 3:
                        comment += "Val(OP0):0x%x; " % (int(jsondata["instruction"][i]["inst_mem_addr_dst0"],16)) 
                except:
                    if c < MAX_LOG_ROUNDS:
                        print_mesg("    Val(OP0)@0x%x@instr number:%07d = No memory data found in JSON file" % (ea, i))
                    if c < 3:
                        comment += "Val(OP0):NotFound; " 

            if self.cmd == "FindValueOP1":
                try:
                    if c < MAX_LOG_ROUNDS:
                        print_mesg("    Val(OP1)@0x%x@instr number:%07d = 0x%x" % (ea, i, int(jsondata["instruction"][i]["inst_mem_addr_src0"],16)))
                    if c < 3:
                        comment += "Val(OP1):0x%x; " % (int(jsondata["instruction"][i]["inst_mem_addr_src0"],16)) 
                except:
                    if c < MAX_LOG_ROUNDS:
                        print_mesg("    Val(OP1)@0x%x@instr number:%07d = No memory data found in JSON file" % (ea, i))
                    if c < 3:
                        comment += "Val(OP1):NotFound; " 

        # Get existing commend and add our dynamic data to it.
        org_cmt = idc.GetCommentEx(ea, False)
        if org_cmt != None:
            new_comment = org_cmt + "\n" + comment
        else:
            new_comment = comment

        idc.MakeComm(ea, new_comment)        

    def _set_ida_comment_mem_ptr(self, ea, trace_instr_num_list):
        """ Prints out data if operant is a pointer stored in a memory address and adds a comment to the disasm view"""
        comment = ""

        if not trace_instr_num_list:
            comment = "0x%x not in trace" % ea

        for c,i in enumerate(trace_instr_num_list):
            if self.cmd == "Get_Mem_Ptr_OP0": 
                try:
                    if c < MAX_LOG_ROUNDS:
                        print_mesg("    Mem(*OP0)@0x%x@instr number:%07d = %s" % (ea, i, jsondata["instruction"][i]["inst_mem_addr_dst0_data"]))
                    if c < 3:
                        comment += "Mem(*OP0):%s; " % (str(jsondata["instruction"][i]["inst_mem_addr_dst0_data"])) 
                        #if c < 2: comment += "\n"
                except:
                    if c < MAX_LOG_ROUNDS:
                        print_mesg("    Mem(*OP0)@0x%x: No memory data found in JSON file" % ea)
                    if c < 3:
                        comment += "Mem(*OP0):NotFound; "
                        #if c < 2: comment += "\n" 

            if self.cmd == "Get_Mem_Ptr_OP1":
                try:
                    if c < MAX_LOG_ROUNDS:
                        print_mesg("    Mem(*OP1)@0x%x@instr number:%07d = %s" % (ea, i, jsondata["instruction"][i]["inst_mem_addr_src0_data"]))
                    if c < 3:
                        comment += "Mem(*OP1):%s; " % (str(jsondata["instruction"][i]["inst_mem_addr_src0_data"])) 
                        #if c < 2: comment += "\n"
                except:
                    if c < MAX_LOG_ROUNDS:
                        print_mesg("    Mem(*OP1)@0x%x: No memory data found in JSON file" % ea)
                    if c < 3:
                        comment += "Mem(*OP1):NotFound; " 
                        #if c < 2: comment += "\n"

        # Get existing commend and add our dynamic data to it.
        org_cmt = idc.GetCommentEx(ea, False)
        if org_cmt != None:
            new_comment = org_cmt + "\n" + comment
        else:
            new_comment = comment

        idc.MakeComm(ea, new_comment)

    def _set_ida_comment_mem_ptr_ptr(self, ea, trace_instr_num_list):
        """ Prints out data if operant is a pointer to a pointer stored in a memory address and adds a comment to the disasm view"""
        comment = ""

        if not trace_instr_num_list:
            comment = "0x%x not in trace" % ea

        for c,i in enumerate(trace_instr_num_list):
            if self.cmd == "Get_Mem_Ptr_Ptr_OP0": 
                try:
                    if c < MAX_LOG_ROUNDS:
                        print_mesg("    **OP0@0x%x@instr number:%07d = %s" % (ea, i, jsondata["instruction"][i]["inst_mem_addr_dst0_data_ptr_data"]))
                    if c < 3:
                        comment += "Mem(**OP0):%s; " % (str(jsondata["instruction"][i]["inst_mem_addr_dst0_data_ptr_data"])) 
                        #if c < 2: comment += "\n"
                except:
                    if c < MAX_LOG_ROUNDS:
                        print_mesg("    **OP0@0x%x: No memory data found in JSON file" % ea)
                    if c < 3:
                        comment += "Mem(**OP0):NotFound; " 
                        #if c < 2: comment += "\n"

            if self.cmd == "Get_Mem_Ptr_Ptr_OP1":
                try:
                    if c < MAX_LOG_ROUNDS:
                        print_mesg("    **OP1@0x%x@instr number:%07d = %s" % (ea, i, jsondata["instruction"][i]["inst_mem_addr_src0_data_ptr_data"]))
                    if c < 3:
                        comment += "Mem(**OP1):%s; " % (str(jsondata["instruction"][i]["inst_mem_addr_src0_data_ptr_data"])) 
                        #if c < 2: comment += "\n"
                except:
                    if c < MAX_LOG_ROUNDS:
                        print_mesg("    **OP1@0x%x: No memory data found in JSON file" % ea)
                    if c < 3:
                        comment += "Mem(**OP1):NotFound; " 
                        #if c < 2: comment += "\n"

        # Get existing commend and add our dynamic data to it. [ TBD: create a separate method for it for reuse ]
        org_cmt = idc.GetCommentEx(ea, False)
        if org_cmt != None:
            new_comment = org_cmt + "\n" + comment
        else:
            new_comment = comment

        idc.MakeComm(ea, new_comment)
 
    def _set_ida_comment_regmenu_mem_ptr(self, ea, reg, trace_instr_num_list):
        """ Prints out the content stored in the register and the memory data the register is pointing to and adds a comment to the disasm view"""
        comment = ""

        if not trace_instr_num_list:
            comment = "0x%x not in trace" % ea

        for c,i in enumerate(trace_instr_num_list):
            if c < MAX_LOG_ROUNDS:
                print_mesg("    %s(=%s)@instr number:%07d = %s" % (reg, jsondata["instruction"][i][reg], i, jsondata["instruction"][i][reg + "_ptr_data"]))
            if c < 3:
                s_pdata  = str(jsondata["instruction"][i][reg + "_ptr_data"])
                regval   = int(jsondata["instruction"][i][reg],16)

                if not s_pdata == "NO_DATA":
                    s_cmt   = str("%s(0x%x)=%s; " % (reg, regval, s_pdata)) #IDA doesn't like unicode type
                    #if c < 2: s_cmt += "\n"
                else:
                    s_cmt   = str("%s(0x%x); " % (reg, regval))

                comment += s_cmt

        # Get existing commend and add our dynamic data to it.
        org_cmt = idc.GetCommentEx(ea, False)
        if org_cmt != None:
            new_comment = org_cmt + "\n" + comment
        else:
            new_comment = comment

        idc.MakeComm(ea, new_comment)

    def _get_trace_instr_list_for_op_reg(self, reg, opnum, ea):
        """ Get instruction number list from JSON trace file for ea address and build JSON file register name, if operant is a register"""

        # if e.g. R9D get main register e.g. R9
        if reg[1].isdigit():
            reg = reg[:2]

        # else it is e.g. eax, replace e with x = xax
        else:
            reg = reg[-2:].lower()
            reg = "x{}".format(reg)

        if reg.endswith('l'):
            reg = reg[:-1] + 'x'

        trace_instr_num_list = []
        trace_instr_num_list = self._find_instr_addr_in_json(ea, trace_instr_num_list)

        print_mesg("Build list for instruction=0x%x OP%d reg=%s length_trace_instr_num_list=%d" % (ea, opnum, reg, len(trace_instr_num_list)),7)

        if not trace_instr_num_list:
            print_mesg("Instruction address 0x%x not found in trace file." % ea)

        return reg, trace_instr_num_list

    def _get_trace_instr_list_for_op_mem(self, ea):
        """ Get instruction number list from JSON trace file for ea address, if operant is a memory address"""

        trace_instr_num_list = []
        trace_instr_num_list = self._find_instr_addr_in_json(ea, trace_instr_num_list)

        print_mesg("Build list for ea=0x%x length_trace_instr_num_list=%d" % (ea, len(trace_instr_num_list)),7)

        if not trace_instr_num_list:
            print_mesg("Instruction address 0x%x not found in trace file." % ea)

        return trace_instr_num_list

    def _op_count(self, ea):
        """Return the number of operands of a given instruction"""

        #length = idaapi.decode_insn(ea)
        for c,v in enumerate(idaapi.cmd.Operands):
            if v.type == idaapi.o_void:
                return c
            continue
        return c

    def _find_instr_addr_in_json(self, ea, trace_instr_num_list):
        """ Return a list of all instructions from the JSON file which match the ea address"""

        #num_instr = len(jsondata["instruction"])
        i=0
        c=0
        for instr in jsondata["instruction"]:                               # TBD change to eval..
            jsonaddr = int(jsondata["instruction"][i]["address"], 16)
            #print_mesg("jsonaddr=0x%x  ea=0x%x\n" %(jsonaddr,ea))
            if jsonaddr == ea:
                print_mesg("    %d. Found instr address    : %x" % (i, ea),7)
                trace_instr_num_list.append(i)
                c += 1
                if c > MAX_INSTR_COUNT-1: break
            i += 1

        print_mesg("    Number of times instruction at address (0x%x) executed in trace file: %d" % (ea, len(trace_instr_num_list)))

        return trace_instr_num_list

class ddrPlugin(idaapi.plugin_t):
    """
    The IDA plugin stub for DDR.
    """

    print_mesg("Start initalizing plugin...")

    #
    # Plugin flags:
    # - PLUGIN_MOD: Lighthouse is a plugin that may modify the database
    # - PLUGIN_PROC: Load/unload Lighthouse when an IDB opens / closes
    # - PLUGIN_HIDE: Hide Lighthouse from the IDA plugin menu
    #
    flags = idaapi.PLUGIN_PROC | idaapi.PLUGIN_MOD 
    comment = "Dynamic Data Resolver Plugin"
    help = ""
    wanted_name = "DDR"
    wanted_hotkey = ""

    def activate(self,ctx):
        return 1

    def init(self):
        """
        This is called by IDA when it is loading the plugin.
        """

        global arch_bits
        global reg_list

        info = idaapi.get_inf_structure()

        if info.is_64bit():
            arch_bits = 64
            print_mesg("We are in a 64bit world...",7)
            reg_list = ["xax","xbx","xcx","xdx","xsp","xbp","xsi","xdi","r8","r9","r10","r11","r12","r13","r14","r15"]
        elif info.is_32bit():
            arch_bits = 32
            print_mesg("We are in a 32bit world...",7)
            reg_list = ["xax","xbx","xcx","xdx","xsp","xbp","xsi","xdi"]
        else:
            arch_bits = 16
            print_mesg("[ERROR] We are in a 64bit world, this plugin only supports 64/32bit enviroments. Unloading plugin.",7)
            return idaapi.PLUGIN_SKIP

        # create the different menu actions  TODO: build loop for this crap
        self._add_action(act_name_load_file          , "Load DynRIO file",              "Ctrl+Shift+F12" , "DDR Tool", DDR_ida_action_handler("LoadFile"))
        self._add_action(act_name_Get_Values_OP0     , "Get values for operant 0",       None            , "DDR Tool", DDR_ida_action_handler("FindValueOP0"))
        self._add_action(act_name_Get_Values_OP1     , "Get values for operant 1",       None            , "DDR Tool", DDR_ida_action_handler("FindValueOP1"))
        self._add_action(act_name_Get_Mem_Ptr_OP0    , "Get memory for ptr in op 0",     None            , "DDR Tool", DDR_ida_action_handler("Get_Mem_Ptr_OP0"))
        self._add_action(act_name_Get_Mem_Ptr_OP1    , "Get memory for ptr in op 1",     None            , "DDR Tool", DDR_ida_action_handler("Get_Mem_Ptr_OP1"))
        self._add_action(act_name_Get_Mem_Ptr_Ptr_OP0, "Get memory for ptr ptr in op 0", None            , "DDR Tool", DDR_ida_action_handler("Get_Mem_Ptr_Ptr_OP0"))
        self._add_action(act_name_Get_Mem_Ptr_Ptr_OP1, "Get memory for ptr ptr in op 1", None            , "DDR Tool", DDR_ida_action_handler("Get_Mem_Ptr_Ptr_OP1"))
        self._add_action(act_name_Get_Mem_Ptr_xax  , "Get memory for ptr in xax",        None            , "DDR Tool", DDR_ida_action_handler("Get_Mem_Ptr_xax"))
        self._add_action(act_name_Get_Mem_Ptr_xbx  , "Get memory for ptr in xbx",        None            , "DDR Tool", DDR_ida_action_handler("Get_Mem_Ptr_xbx"))
        self._add_action(act_name_Get_Mem_Ptr_xcx  , "Get memory for ptr in xcx",        None            , "DDR Tool", DDR_ida_action_handler("Get_Mem_Ptr_xcx"))
        self._add_action(act_name_Get_Mem_Ptr_xdx  , "Get memory for ptr in xdx",        None            , "DDR Tool", DDR_ida_action_handler("Get_Mem_Ptr_xdx"))
        self._add_action(act_name_Get_Mem_Ptr_xsp  , "Get memory for ptr in xsp",        None            , "DDR Tool", DDR_ida_action_handler("Get_Mem_Ptr_xsp"))
        self._add_action(act_name_Get_Mem_Ptr_xbp  , "Get memory for ptr in xbp",        None            , "DDR Tool", DDR_ida_action_handler("Get_Mem_Ptr_xbp"))
        self._add_action(act_name_Get_Mem_Ptr_xsi  , "Get memory for ptr in xsi",        None            , "DDR Tool", DDR_ida_action_handler("Get_Mem_Ptr_xsi"))
        self._add_action(act_name_Get_Mem_Ptr_xdi  , "Get memory for ptr in xdi",        None            , "DDR Tool", DDR_ida_action_handler("Get_Mem_Ptr_xdi"))

        if arch_bits == 64:
            self._add_action(act_name_Get_Mem_Ptr_r8   , "Get memory for ptr in r8" ,        None            , "DDR Tool", DDR_ida_action_handler("Get_Mem_Ptr_r8"))
            self._add_action(act_name_Get_Mem_Ptr_r9   , "Get memory for ptr in r9" ,        None            , "DDR Tool", DDR_ida_action_handler("Get_Mem_Ptr_r9"))
            self._add_action(act_name_Get_Mem_Ptr_r10  , "Get memory for ptr in r10",        None            , "DDR Tool", DDR_ida_action_handler("Get_Mem_Ptr_r10"))
            self._add_action(act_name_Get_Mem_Ptr_r11  , "Get memory for ptr in r11",        None            , "DDR Tool", DDR_ida_action_handler("Get_Mem_Ptr_r11"))
            self._add_action(act_name_Get_Mem_Ptr_r12  , "Get memory for ptr in r12",        None            , "DDR Tool", DDR_ida_action_handler("Get_Mem_Ptr_r12"))
            self._add_action(act_name_Get_Mem_Ptr_r13  , "Get memory for ptr in r13",        None            , "DDR Tool", DDR_ida_action_handler("Get_Mem_Ptr_r13"))
            self._add_action(act_name_Get_Mem_Ptr_r14  , "Get memory for ptr in r14",        None            , "DDR Tool", DDR_ida_action_handler("Get_Mem_Ptr_r14"))
            self._add_action(act_name_Get_Mem_Ptr_r15  , "Get memory for ptr in r15",        None            , "DDR Tool", DDR_ida_action_handler("Get_Mem_Ptr_r15"))

        self._add_action(act_name_Strings_View , "Show strings in Trace Strings View",                 None , "DDR Tool", DDR_ida_action_handler("Display_Strings_View"))
        self._add_action(act_name_Set_Num_Hits_Cmt , "Set number of trace hits for IDA DISASM View",   None , "DDR Tool", DDR_ida_action_handler("Get_Set_Num_Hits_Cmt"))
        self._add_action(act_name_Set_Num_Hits_IdaLog , "Set number of trace hits for IDA log window", None , "DDR Tool", DDR_ida_action_handler("Get_Set_Num_Hits_IdaLog"))
        self._add_action(act_name_DeleteNonRepeatableComments, "Delete non-repeatable comments",       None , "DDR Tool", DDR_ida_action_handler("DeleteNonRepeatableComments"))

        # attach action(s) to 'Edit->' menu
        result = idaapi.attach_action_to_menu(
            "File/Load file/",      # Relative path of where to add the action
            act_name_load_file,     # The action ID (see above)
            idaapi.SETMENU_APP      # We want to append the action after ^
        )
        if not result:
            idaapi.warning("[DDR] Failed to attach action (act_name_load_file) to main menu")
        else:
            print_mesg("Attached [act_name_load_file] to main menu",7)

        # attach action(s) to the toolbar
        if idaapi.attach_action_to_toolbar("AnalysisToolBar", act_name_load_file):
            print_mesg("Action [act_name_load_file] attached to toolbar.",7)
        else:
            idaapi.warning("[DDR] Failed to attach action [act_name_load_file] to toolbar.")

        # attach action(s) to context menu
        class Hooks(idaapi.UI_Hooks):
            def finish_populating_tform_popup(self, form, popup):
                # We'll add our action to all "IDA View-*"s.
                # If we wanted to add it only to "IDA View-A", we could
                # also discriminate on the widget's title:
                #
                #  if idaapi.get_tform_title(form) == "IDA View-A":
                #      ...
                #
                # TBD: build loop for this crap
                self._add_ida_popup(act_name_Get_Values_OP0     , form, popup, "DDR/")
                self._add_ida_popup(act_name_Get_Values_OP1     , form, popup, "DDR/")
                self._add_ida_popup(act_name_Get_Mem_Ptr_OP0    , form, popup, "DDR/")
                self._add_ida_popup(act_name_Get_Mem_Ptr_OP1    , form, popup, "DDR/")
                self._add_ida_popup(act_name_Get_Mem_Ptr_Ptr_OP0, form, popup, "DDR/")
                self._add_ida_popup(act_name_Get_Mem_Ptr_Ptr_OP1, form, popup, "DDR/")
                self._add_ida_popup(act_name_Get_Mem_Ptr_xax    , form, popup, "DDR/Register/Ptr")
                self._add_ida_popup(act_name_Get_Mem_Ptr_xbx    , form, popup, "DDR/Register/Ptr")
                self._add_ida_popup(act_name_Get_Mem_Ptr_xcx    , form, popup, "DDR/Register/Ptr")
                self._add_ida_popup(act_name_Get_Mem_Ptr_xdx    , form, popup, "DDR/Register/Ptr")
                self._add_ida_popup(act_name_Get_Mem_Ptr_xsp    , form, popup, "DDR/Register/Ptr")
                self._add_ida_popup(act_name_Get_Mem_Ptr_xbp    , form, popup, "DDR/Register/Ptr")
                self._add_ida_popup(act_name_Get_Mem_Ptr_xsi    , form, popup, "DDR/Register/Ptr")
                self._add_ida_popup(act_name_Get_Mem_Ptr_xdi    , form, popup, "DDR/Register/Ptr")

                if arch_bits == 64:
                    self._add_ida_popup(act_name_Get_Mem_Ptr_r8     , form, popup, "DDR/Register/Ptr")
                    self._add_ida_popup(act_name_Get_Mem_Ptr_r9     , form, popup, "DDR/Register/Ptr")
                    self._add_ida_popup(act_name_Get_Mem_Ptr_r10    , form, popup, "DDR/Register/Ptr")
                    self._add_ida_popup(act_name_Get_Mem_Ptr_r11    , form, popup, "DDR/Register/Ptr")
                    self._add_ida_popup(act_name_Get_Mem_Ptr_r12    , form, popup, "DDR/Register/Ptr")
                    self._add_ida_popup(act_name_Get_Mem_Ptr_r13    , form, popup, "DDR/Register/Ptr")
                    self._add_ida_popup(act_name_Get_Mem_Ptr_r14    , form, popup, "DDR/Register/Ptr")
                    self._add_ida_popup(act_name_Get_Mem_Ptr_r15    , form, popup, "DDR/Register/Ptr")
                
                self._add_ida_popup(act_name_Strings_View       , form, popup, "DDR/")
                self._add_ida_popup(act_name_Set_Num_Hits_Cmt   , form, popup, "DDR/")
                self._add_ida_popup(act_name_Set_Num_Hits_IdaLog, form, popup, "DDR/")
                self._add_ida_popup(act_name_DeleteNonRepeatableComments, form, popup, "DDR/")

            def _add_ida_popup(self, act_name, form, popup, menuname):
                """
                Helper function to add a menu to the context menu in IDA if we are in the Disasm view
                """
                
                if idaapi.get_tform_type(form) == idaapi.BWN_DISASM:
                    print_mesg("we are in DISASM view.",7)
                    if (idaapi.attach_action_to_popup(form, popup, act_name, menuname)):
                        print_mesg("added [%s] to context menu." % act_name,7)
                        pass
                    else:
                        idaapi.warning("[DDR] Failed to add [%s] to context menu." % act_name)

                else:
                    print_mesg("we are NOT in DISASM view.",7)
                    return False

                return True

        self.hooks = Hooks()
        if (self.hooks.hook()):
            print_mesg("All actions attached to context menu.",7)
        else:
            idaapi.warning("[DDR] Hooking context menu failed.")

        try:
            print_mesg("DDR plugin started and initalized.")
            logger.info("DDR plugin started")
            print_mesg("Using Logfile: " + ddr_logfilename)
  
        except Exception as e:
            idaapi.warning("[DDR] init failed.")
            logger.exception("Exception details:")
            return idaapi.PLUGIN_SKIP

        # tell IDA to keep the plugin loaded (everything is okay)
        return idaapi.PLUGIN_KEEP

    def run(self, arg):
        """
        This is called by IDA when this file is loaded as a script.
        """
        idaapi.warning("[DDR] This plugin cannot be run as a script in IDA.")

    def update(self, ctx):
        return idaapi.AST_ENABLE_FOR_FORM if ctx.form_type == idaapi.BWN_DISASM else idaapi.AST_DISABLE_FOR_FORM

    def term(self):
        """
        This is called by IDA when it is unloading the plugin.
        """

        if arch_bits == 32 or arch_bits == 64:
            self._unregister_ida_action(act_name_load_file)
            self._unregister_ida_action(act_name_Get_Values_OP0)
            self._unregister_ida_action(act_name_Get_Values_OP1)
            self._unregister_ida_action(act_name_Get_Mem_Ptr_OP0)
            self._unregister_ida_action(act_name_Get_Mem_Ptr_OP1)
            self._unregister_ida_action(act_name_Get_Mem_Ptr_Ptr_OP0)
            self._unregister_ida_action(act_name_Get_Mem_Ptr_Ptr_OP1)
            self._unregister_ida_action(act_name_Get_Mem_Ptr_xax)
            self._unregister_ida_action(act_name_Get_Mem_Ptr_xbx)
            self._unregister_ida_action(act_name_Get_Mem_Ptr_xcx)
            self._unregister_ida_action(act_name_Get_Mem_Ptr_xdx)
            self._unregister_ida_action(act_name_Get_Mem_Ptr_xsp)
            self._unregister_ida_action(act_name_Get_Mem_Ptr_xbp)
            self._unregister_ida_action(act_name_Get_Mem_Ptr_xsi)
            self._unregister_ida_action(act_name_Get_Mem_Ptr_xdi)
            self._unregister_ida_action(act_name_Strings_View)
            self._unregister_ida_action(act_name_Set_Num_Hits_Cmt)
            self._unregister_ida_action(act_name_Set_Num_Hits_IdaLog)
            self._unregister_ida_action(act_name_DeleteNonRepeatableComments)

        if arch_bits == 64: 
            self._unregister_ida_action(act_name_Get_Mem_Ptr_r8)
            self._unregister_ida_action(act_name_Get_Mem_Ptr_r9)
            self._unregister_ida_action(act_name_Get_Mem_Ptr_r10)
            self._unregister_ida_action(act_name_Get_Mem_Ptr_r11)
            self._unregister_ida_action(act_name_Get_Mem_Ptr_r12)
            self._unregister_ida_action(act_name_Get_Mem_Ptr_r13)
            self._unregister_ida_action(act_name_Get_Mem_Ptr_r14)
            self._unregister_ida_action(act_name_Get_Mem_Ptr_r15)
            
        try:
            print_mesg("plugin terminated.")
        except Exception as e:
            idaapi.warning("[DDR] Failed to cleanly unload DDR from IDA.")
            logger.exception("Failed to cleanly unload DDR from IDA.")

    def _unregister_ida_action(self, act_name):
        """
        Helper function to unregister an IDA action
        """

        if idaapi.unregister_action(act_name):
            print_mesg("[%s] action unregistered from IDA." % act_name,7)
        else:
            idaapi.warning("Failed to unregister ({action_name}) action in IDA.".format(action_name=act_name)) 

    def _add_action(self, act_name, act_text, act_shortcut, act_tooltip, act_handler):
        """
        Helper function to add an action description to IDA
        """
        action_desc = idaapi.action_desc_t(
            act_name,                  # The action name
            act_text,                  # The action text
            act_handler,               # The action handler
            act_shortcut,              # Optional: action shortcut
            act_tooltip                # Optional: tooltip
                                       # Optional: the action icon
        )

        # register the action with IDA
        result = idaapi.register_action(action_desc)
        if not result: 
            idaapi.warning("[DDR] Failed to register action({action_name}) with IDA".format(action_name=act_name))

class MyChoose2(Choose2):

    def __init__(self, title, items, flags=0, width=None, height=None, embedded=False, modal=False):

        columns = [ ["Instruction #", 6], ["Address", 12], ["Type", 15], ["String Hex", 25], ["String", 12], ["Disasm", 35] ]
        
        self.lines_n = []

        Choose2.__init__(
            self,
            title,
            columns,
            flags = flags,
            width = width,
            height = height,
            embedded = embedded)
        self.n = 0
        self.items = items
        self.icon = -1
        #self.selcount = 0
        self.modal = modal
        #self.popup_names = ["Inzert", "Del leet", "Ehdeet", "Ree frech"]

        print("created %s" % str(self))

    def OnClose(self):
        # Window closed
        print_mesg("Trace View window closed" , 7)
        pass

    def OnEditLine(self, n):
        # Click on "Edit.. menu"
        print_mesg("Not implemented.")

    def OnInsertLine(self):
        # Click on "Insert.. menu"
        print_mesg("Not implemented.")

    def OnDeleteLine(self, n):
        # Click on "Delete menu"
        del self.items[n]
        print_mesg("Line %d deleted." % n , 7)
        return n

    def OnRefresh(self, n):
        # Click on "Refresh menu"
        print_mesg("Trace View window refreshed %d" % n)
        return n

    def OnSelectLine(self, n):
        # double click on line
        self.lines_n.append(n)
        print_mesg("Line: %d  Address: %s  Name:%s" % (n, str(self.items[n][0]), str(self.items[n][1])), 7)
        ea = int(self.items[n][1],16) 
        idc.Jump(ea)

    def OnGetLine(self, n):
        return self.items[n]

    def OnGetSize(self):
        n = len(self.items)
        return n

    def OnGetIcon(self, n):
        r = self.items[n]
        t = self.icon + r[1].count("*")
        return t

    def OnGetLineAttr(self, n):
        # Highlight line 1 in blue:
        if n in self.lines_n:
            self.highlight_line = False
            return [0xFF0000, 0]
        
        return

    def show(self):
        return self.Show(self.modal) >= 0


# --- For future use Tree View Class  ---
#
#  tree_window = CBaseTreeViewer()
#  tree_window.Show("TreeView Tab Name")
#
class CBaseTreeViewer(PluginForm):
    def populate_tree(self):
        # Clear previous items
        self.tree.clear()

    def OnCreate(self, form):
        # Get parent widget
        self.parent = idaapi.PluginForm.FormToPyQtWidget(form)

        # Create tree control
        self.tree = QtWidgets.QTreeWidget()
        self.tree.setHeaderLabels(("TreeWindowSubName",))
        self.tree.setColumnWidth(0, 100)

        # Create layout
        layout = QtWidgets.QVBoxLayout()
        layout.addWidget(self.tree)

        TreeBranch1 = QtWidgets.QTreeWidgetItem(self.tree)
        TreeBranch1.setText(0, "TreeBranch1")
        TreeBranch1.ea = idc.BADADDR
        leaf1 = QtWidgets.QTreeWidgetItem(TreeBranch1)
        leaf1.setText(0, "%s %s %s" % ("Leaf1.0","Leaf1.1","Leaf1.2"))
        leaf1.ea = idc.BADADDR
        leaf2 = QtWidgets.QTreeWidgetItem(TreeBranch1)
        leaf2.setText(0, "%s %s %s" % ("Leaf2.0","Leaf2.1","Leaf2.2"))
        leaf2.ea = idc.BADADDR
        TreeBranch2 = QtWidgets.QTreeWidgetItem(self.tree)
        TreeBranch2.setText(0, "TreeBranch2")
        leaf3 = QtWidgets.QTreeWidgetItem(TreeBranch2)
        leaf3.setText(0, "%s %s %s" % ("Leaf3.0","Leaf3.1","Leaf3.2"))
        leaf3.ea = idc.BADADDR

        # Populate PluginForm
        self.parent.setLayout(layout)

    def Show(self, title):
        return PluginForm.Show(self, title, options = PluginForm.FORM_PERSIST)